// Abdalla Abdelmagid
public class Main {
    public static void main(String[] args) {
        SortedNameList name_list = new SortedNameList();

        name_list.add("Smith");
        name_list.add("Jones");

        name_list.print();
    }    
}
