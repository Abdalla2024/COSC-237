// Abdalla Abdelmagid

public class DivideByZeroException extends RuntimeException {
  
}