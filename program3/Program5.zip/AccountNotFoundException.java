// Abdalla Abdelmagid

public class AccountNotFoundException extends RuntimeException{
    
}
