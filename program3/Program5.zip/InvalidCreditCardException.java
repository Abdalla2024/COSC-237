public class InvalidCreditCardException extends RuntimeException {
    
}
