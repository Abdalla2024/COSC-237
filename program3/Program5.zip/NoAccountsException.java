// Abdalla Abdelmagid

public class NoAccountsException extends RuntimeException{
    
}
