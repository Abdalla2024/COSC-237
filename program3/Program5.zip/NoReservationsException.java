// Abdalla Abdelmagid

public class NoReservationsException extends RuntimeException{
    
}
