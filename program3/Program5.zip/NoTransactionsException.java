// Abdalla Abdelmagid

public class NoTransactionsException extends RuntimeException{
    
}
