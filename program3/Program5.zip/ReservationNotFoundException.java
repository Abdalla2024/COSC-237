// Abdalla Abdelmagid

public class ReservationNotFoundException extends RuntimeException{
    
}
