// Abdalla Abdelmagid

public class ReservedVehicleException extends RuntimeException{

}
