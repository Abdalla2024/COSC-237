// Abdalla Abdelmagid

public class UnreservedVehicleException extends RuntimeException {

}
