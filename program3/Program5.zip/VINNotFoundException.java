// Abdalla Abdelmagid

public class VINNotFoundException extends RuntimeException {
    
}
