// Abdalla Abdelmagid

public class VehicleNotFoundException extends RuntimeException{
    
}
